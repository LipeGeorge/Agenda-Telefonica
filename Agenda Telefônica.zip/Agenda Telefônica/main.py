#--encoding:utf-8--#

#Aqui é apenas um arquivo para execução, nada demais.

#Import usados nessa parte do código.
import telainicial

telainicial.mostrar()