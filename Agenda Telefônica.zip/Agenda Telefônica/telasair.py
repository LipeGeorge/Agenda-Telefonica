#--encoding:utf-8--#

#Import usados nessa parte do código.
import os
import sys

def mostrar(): #Função para a apresentação da mensagem quando o usuário estiver encerrando o programa.
	os.system('cls||clear')
	print('Encerrando programa: 3 .. 2 .. 1')
	print('Programa Encerrado!')
	sys.exit()